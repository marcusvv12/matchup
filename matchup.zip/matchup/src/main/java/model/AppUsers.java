package model;

public class AppUsers {
    private int id;
    private String email;
    private String password;
    private int idade;

    public AppUsers() {
        this.id = 0;
        this.email = "";
        this.password = "";
        this.idade = 0;
    }

    public AppUsers(int id, String email, String password, int idade) {
        setId(id);
        setEmail(email);
        setPassword(password);
        setidade(idade);
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setidade(int idade) {
        this.idade = idade;
    }

    public int getidade() {
        return idade;
    }

    @Override
    public String toString() {
        return "User ID: " + id + ", Email: " + email + ", Premium: " + idade;
    }
}
